package tuan1.BAIHINHTRON;

public class TOADO {

    // Khai bao thuoc tinh
    private double x;
    private double y;

    // Getter x
    public double getX() {
        return x;
    }

    // Setter x
    public void setX(double x) {
        this.x = x;
    }

    // Getter y
    public double getY() {
        return y;
    }

    // Setter y
    public void setY(double y) {
        this.y = y;
    }

    // Constructor
    public TOADO(double x, double y) {
        this.x = x;
        this.y = y;
    }
}