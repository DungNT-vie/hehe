package tuan1.BAIHINHTRON;

public class HINHTRON {

    private double banKinh;
    private TOADO tam;

    public double getBanKinh() {
        return banKinh;
    }

    public void setBanKinh(double banKinh) {
        this.banKinh = banKinh;
    }

    public TOADO getTam() {
        return tam;
    }

    public void setTam(TOADO tam) {
        this.tam = tam;
    }

    // Constructor
    public HINHTRON(double banKinh, TOADO tam) {
        this.banKinh = banKinh;
        this.tam = tam;
    }

    // Tinh chu vi
    public double getChuVi() {
        return 2 * Math.PI * banKinh;
    }

    // Tinh dien tich
    public double getDienTich() {
        return Math.PI * banKinh * banKinh;
    }

    public static void main(String[] args) {

        TOADO td = new TOADO(2, 3);

        HINHTRON ht = new HINHTRON(5, td);

        System.out.println("Toa do tam:");
        System.out.println("x = " + ht.getTam().getX());
        System.out.println("y = " + ht.getTam().getY());

        System.out.println("Ban kinh: " + ht.getBanKinh());
        System.out.println("Chu vi: " + ht.getChuVi());
        System.out.println("Dien tich: " + ht.getDienTich());
    }
}
